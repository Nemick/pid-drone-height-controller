
#include "wokwi-api.h"
#include <stdlib.h>
#include <stdio.h>

typedef struct {
  pin_t pin_VCC;
  pin_t pin_GND;
} dc_motor_t;

static void update_motor(void *user_data, pin_t pin, uint32_t value) {
  dc_motor_t *motor = (dc_motor_t *)user_data;

  // Read the VCC and GND pins to determine polarity
  int VCC = pin_read(motor->pin_VCC);
  int GND = pin_read(motor->pin_GND);

  const char *direction = "STOP";
  float speed = 0;

  if (VCC && !GND) {
    direction = "FWD";  // Forward direction
    speed = 100.0;  // Assume full speed for simplicity
  } else if (!VCC && GND) {
    direction = "REV";  // Reverse direction
    speed = 100.0;  // Assume full speed for simplicity
  }

  // Prepare the label with speed and direction
  char label[32];
  snprintf(label, sizeof(label), "Speed: %.0f%%, Dir: %s", speed, direction);

  // Use the label for visualization in Wokwi UI
  // Assuming you have a custom label component set up in your diagram
  // You can bind this text to the label component via Wokwi UI instead of using pin_write()

  // NOTE: In practice, you'd link this label to the Wokwi UI via an element or a GUI update feature.
}

void chip_init() {
  dc_motor_t *motor = malloc(sizeof(dc_motor_t));

  // Initialize the VCC and GND pins
  motor->pin_VCC = pin_init("VCC", INPUT);  // Power input pin
  motor->pin_GND = pin_init("GND", INPUT);  // Ground input pin

  // Set up pin watchers to monitor changes on VCC and GND
  const pin_watch_config_t cfg = {
    .edge = BOTH,
    .pin_change = update_motor,
    .user_data = motor
  };

  pin_watch(motor->pin_VCC, &cfg);  // Watch the VCC pin
  pin_watch(motor->pin_GND, &cfg);  // Watch the GND pin
}




